#!/bin/bash

echo "🔪 Проверяю и очищаю порт 8000..."
PID_8000=$(lsof -ti :8000)

if [ -n "$PID_8000" ]; then
  echo "❗ Найден процесс на порту 8000 (PID $PID_8000). Убиваю..."
  kill -9 $PID_8000
else
  echo "✅ Порт 8000 свободен"
fi

# 🔄 НЕ убиваем ngrok — оставляем процессы активными
echo "✅ Пропускаю остановку ngrok. Если он запущен — пусть работает."

echo "🚀 Запускаю сервер FastAPI (uvicorn)..."
uvicorn main:app --reload
