import time
import requests
import hmac
from hashlib import sha256
import logging

# 🔐 Прямо указываем ключи (только для отладки, не в продакшн!)
API_URL = "https://open-api.bingx.com"
API_KEY = "ZXVQZnksSTXRCZCFfKvVH3K7oz2kyFk9flhZItr1xTa9517kp8RQbZ7HVazf8x8gfpferagWPtIaXC91IT73Lg"
SECRET_KEY = "9AIulgMmhhTqjuy7WU4mvZuOpZaaWEHzAYJgunPs4AZHf6d4DCeNAImHlG03K3CJwSXATOwYsZsBVLeLTykA"

# 🔧 Логгирование
logging.basicConfig(level=logging.INFO)

def get_timestamp():
    return str(int(time.time() * 1000))

def get_sign(secret, payload):
    signature = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), digestmod=sha256).hexdigest()
    logging.info(f"🔐 Signature: {signature}")
    return signature

def parse_params(params):
    sorted_keys = sorted(params)
    param_str = "&".join([f"{key}={params[key]}" for key in sorted_keys])
    if param_str:
        return f"{param_str}&timestamp={get_timestamp()}"
    else:
        return f"timestamp={get_timestamp()}"

def send_request(method, path, params_map):
    params_str = parse_params(params_map)
    signature = get_sign(SECRET_KEY, params_str)
    url = f"{API_URL}{path}?{params_str}&signature={signature}"

    logging.info(f"➡️ Запрос: {url}")
    headers = {
        "X-BX-APIKEY": API_KEY,
    }

    response = requests.request(method, url, headers=headers)
    logging.info(f"📥 Статус: {response.status_code}")
    logging.info(f"📄 Ответ: {response.text}")
    return response.json()

def main():
    path = "/openApi/swap/v3/user/balance"  # 🔁 Контрактный аккаунт (если не подходит — сменим)
    method = "GET"
    params = {}  # Если нужно, добавим marginCoin
    return send_request(method, path, params)

if __name__ == "__main__":
    result = main()
    print("✅ Финальный результат:", result)
